# Presentation outline and video script (13:45 of 15:00)

| # | Slide | Presenter | Time | Running total |
|---|---|---|---|---|
| 1 | Title and team | A | 0:30 | 0:30 |
| 2 | Our workflow: GitHub and AI | B | 1:30 | 2:00 |
| 3 | Why Problem 5-35 | A | 1:00 | 3:00 |
| 4 | Model and finite difference equations | A | 1:30 | 4:30 |
| 5 | Original solution: the plate runs too hot | B | 1:30 | 6:00 |
| 6 | Diagnosis: where is the bottleneck? | B | 1:15 | 7:15 |
| 7 | The adaptation: forced air and coating | A | 1:15 | 8:30 |
| 8 | Adapted steady results | A | 1:00 | 9:30 |
| 9 | Proof of faster cooling | B | 1:30 | 11:00 |
| 10 | Manual audit and AI corrections | A 0:45, B 1:00 | 1:45 | 12:45 |
| 11 | Conclusions | A | 1:00 | 13:45 |

Speaking time: Student A 7:00, Student B 6:45.

## 1. Title and team — A, 0:30
- Display: Numerical Methods in Heat Transfer · Problem 5-35 and a forced-air-cooled adaptation · [Student A] · [Student B] · [Course] · [Date]
- Visual: Figure 1 (model), small.
- Notes: "We solved Problem 5-35 by finite differences, designed an adaptation that cools the plate five times faster, and audited every AI number by hand. I cover the model and the adaptation; [B] covers the workflow, the original results, and the cooling proof."

## 2. Our workflow: GitHub and AI — B, 1:30
- Display: Class templates → detailed prompt → AI draft → hand audit → corrections → code → report · Every prompt and output logged in prompts/ · One script reproduces every number · A second AI audits independently
- Visual: live screen recording of the repository: folder tree, prompt_log.md, ai_error_log.md, commit history with both names.
- Notes: "The AI drafted; we verified. Each prompt and output is saved and dated, and every correction is in the error log."

## 3. Why Problem 5-35 — A, 1:00
- Display: All three special node types: heat flux, interface, convection–radiation · A real code decision: SB-96 ≤ 93 °C · Published density and specific heat for both metals · Nine nodes, every number checkable by hand
- Visual: candidate table from report Section 1.
- Notes: "Problems 5-34 and 5-36 need properties of unknown nonmetals, so a cooling-time model would rest on invented data. Both metals in 5-35 have data sheets whose conductivities match the book exactly."

## 4. Model and finite difference equations — A, 1:30
- Display: Energy balance on each control volume · Interior: T(m−1) − 2T(m) + T(m+1) = 0 · Node 0: −T0 + T1 = −q0·Δx/k1 · Interface: k1·T5 − (k1 + k2)·T6 + k2·T7 = 0 · Node 8: T7 − (1 + hΔx/k2)·T8 = −(hΔx/k2)·T∞ · Exact for linear profiles
- Visual: Figure 1 beside the four equations.
- Notes: "The interface equation does two jobs: one shared temperature and equal flux on both sides. The true profile is linear, so the truncation error is zero and a resistance network can check every node."

## 5. Original solution: the plate runs too hot — B, 1:30
- Display: T0 = 117.9 °C, T6 = 117.2 °C, T8 = 116.6 °C · Limit 93 °C: not compliant, by 24.9 °C · Highest allowable heat flux 559.5 W/m² · Thomas = numpy = exact; 750 W/m² in = 750 W/m² out
- Visual: node table (report 7.4), original curve of Figure 2, hand-written Thomas row 8.
- Notes: "Row 8 divides by −0.0029846. Rounding that coefficient to 1.003 shifts T8 by half a degree, so we carried seven significant figures."

## 6. Diagnosis: where is the bottleneck? — B, 1:15
- Display: Surface resistance = 98.8 % of the total · The metal plates drop only 1.2 °C · Doubling k: −0.3 °C · Thinner plates cool faster but conflict with pressure design · The lever is h_comb
- Visual: resistance table (report 7.10) and four rows of the sensitivity table (report 8.2).
- Notes: "We did not guess. We ran every candidate change through the same code and kept the one that improves both temperature and cooling time without touching the structure."

## 7. The adaptation: forced air and coating — A, 1:15
- Display: Fan-forced 20 °C air plus a high-emissivity coating · h_comb 7.76 → 40 W/m²·K (forced-air range 25–250) · Coating gives 5.7–7.4 W/m²·K of radiation · Bi = 0.064 < 0.1 · Materials, thicknesses and heat flux unchanged
- Visual: h_rad = εσ(Ts + Tsurr)(Ts² + Tsurr²) and a before/after sketch of surface 2.
- Notes: "Before solving we predicted a 77.9 °C shift and a 5.15-fold shorter time constant; slides 8 and 9 confirm both."

## 8. Adapted steady results — A, 1:00
- Display: T0 = 40.0 °C: compliant, 53 °C margin · Same 1.202 °C internal drop; whole profile 77.9 °C lower · Allowable heat flux 559.5 → 2744 W/m² (+390 %)
- Visual: Figures 2 and 3.
- Notes: "The wall still carries 750 W/m² because that flux is prescribed. The gain shows up as lower temperature and higher capacity, not a higher heat rate."

## 9. Proof of faster cooling — B, 1:30
- Display: Test: uniform 93 °C, heat off, bottom adiabatic, target 40 °C · Explicit FD, Δt = 1 s, stable because τ1 = 0.448 ≤ 0.5 · 6.37 h → 1.27 h: 80 % less time, 5.0× faster · Crank–Nicolson, finer grid, lumped and one-term agree within 3.4 %
- Visual: Figure 4, Figure 5 as a small inset.
- Notes: "We compare the time between the same two temperatures, not the final temperatures. First step by hand: T8 = 93 − 0.000776 × 73 = 92.943 °C."

## 10. Manual audit and AI corrections — A 0:45, then B 1:00
- Display: 22 checks recomputed by hand and initialled by both · 5 AI drafting errors found and fixed · Traps avoided: L_c = L, composite Bi, Heisler limits, Fo > 0.2, mesh vs physical Fourier number · Hand-signed certification
- Visual: a scanned hand-calculation page (A); the AI error log table (B).
- Notes: A shows the hand Thomas sweep. B explains error 1: doubling k1 lowered the stable time step to 0.558 s, and the code's own check stopped the run.

## 11. Conclusions — A, 1:00
- Display: Original: 117.9 °C, not compliant · Adapted: 40.0 °C, 53 °C margin · Cooldown 93 → 40 °C: 6.37 h → 1.27 h (−80 %) · One physically justified change, proven by finite differences and four independent checks
- Visual: comparison table (report Section 10).
- Notes: "One change at the controlling resistance fixed compliance and made the plate cool five times faster."

## Recording checklist
- [ ] Rehearse with a timer; aim for 13:45 and stop by 14:30.
- [ ] Show the GitHub repository live on slide 2, not as screenshots.
- [ ] Each student speaks on their own slides; switch voices at slide 10.
- [ ] Speak to the numbers instead of reading the bullets.
