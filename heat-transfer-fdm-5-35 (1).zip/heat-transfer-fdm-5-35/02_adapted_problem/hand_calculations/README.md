# Hand calculations — adapted problem

Scan or photograph your handwritten work and save it here (PDF or PNG), for example:

- thomas_node8_adapted.pdf (report Section 9.3)
- explicit_first_steps.pdf (report Section 9.4)
- audit_checks_rows_13-22.pdf

Both students should initial every page.
