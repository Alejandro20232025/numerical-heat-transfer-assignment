# Hand calculations — original problem

Scan or photograph your handwritten work and save it here (PDF or PNG), named by content, for example:

- thomas_sweep_original.pdf (report Section 7.3)
- audit_checks_rows_1-12.pdf (04_audit/audit_checklist.md)

Both students should initial every page.
